import json
from collections import defaultdict

import MySQLdb
import jieba
from gensim.models.word2vec import Word2Vec as w2v_ori

from .process_3 import call_func as call_func_3
from .process_4 import call_func as call_func_4
from .process_3 import category_priority_nest_list_f as category_priority_nest_list_f_3
from .process_4 import category_priority_nest_list_f as category_priority_nest_list_f_4
from .process_3 import eval_call_conclusion as eval_call_conclusion_3
from .process_4 import eval_call_conclusion as eval_call_conclusion_4

w2v_sim_threshold = 0.85

class Word2Vec():
    def __init__(self, modelPath, kind='bin'):
        """
        创建Word2Vec对象

        modelPath: 模型路径
        kind: 模型类型
            bin: 二进制文件
            txt: 文本文件
        return: 无
        """

        if kind != 'bin':
            kind = False
        else:
            kind = True
        print('loading word2vector model...')
        #self.model = KeyedVectors.load_word2vec_format(modelPath, binary=kind, unicode_errors='ignore')
        self.model = model = w2v_ori.load(modelPath)

    def get_word_vector(self, word):
        """
        获得词向量

        word: 词语
        return: 词向量
        """

        if word in self.model:
            return self.model[word]
        return None

    def word_similarity(self, word1, word2):
        """
        计算词语相似度

        word1: 词语1
        word2: 词语2
        return: 词语1与词语2的相似度
        """

        if word1 not in self.model or word2 not in self.model:
            return 0
        return self.model.similarity(word1, word2)

    def get_similar_Words(self, word, maxReturnNum):
        """
        获得语义相似的词语

        word: 词语
        maxReturnNum: 最大返回词语数量
        return: 词语及相似度 [(word, simi)...]
        """

        if word not in self.model:
            return None
        return self.model.similar_by_word(word, topn=maxReturnNum)

    def __cal_max_similarity(self, centerWord, wordList):
        """
        计算词语与词语列表中词语的最大相似度

        centerWord: 词语
        wordList: 词语列表
        return: 词语与词语列表中词语的最大相似度
        """

        maxSimi = -1
        if centerWord in wordList:
            return 1
        else:
            for word in wordList:
                temp = self.word_similarity(centerWord, word)
                if temp == 0: continue
                if temp > maxSimi: maxSimi = temp
        if maxSimi == -1: return 0
        return maxSimi

    def sentence_similarity(self, sentence1Words, sentence2Words):
        """
        计算句子相似度

        sentence1Words: 句子1词语列表
        sentence2Words: 句子2词语列表
        return: 两个句子的相似度
        """

        if len(sentence1Words) == 0 or len(sentence2Words) == 0:
            return 0
        vector1 = [self.__cal_max_similarity(word, sentence2Words) for word in sentence1Words]
        vector2 = [self.__cal_max_similarity(word, sentence1Words) for word in sentence2Words]
        return (sum(vector1) + sum(vector2)) / (len(vector1) + len(vector2))

    def sentence_weight_similarity(self, sentence1Words, sentence2Words, weightVector1, weightVector2):
        """
        计算句子相似度(带权值)
        每一个词语都有一个对应的权值

        sentence1Words: 句子1词语列表
        sentence2Words: 句子2词语列表
        weightVector1: 句子1权值向量
        weightVector2: 句子2权值向量
        return: 两个句子的相似度
        """

        if len(sentence1Words) == 0 or len(sentence2Words) == 0:
            return 0
        if len(sentence1Words) != len(weightVector1) or len(sentence2Words) != len(weightVector2):
            raise Exception('length of word list and weight vector is different')
        vector1 = [self.__cal_max_similarity(word, sentence2Words) * weight for word, weight in zip(sentence1Words, weightVector1)]
        vector2 = [self.__cal_max_similarity(word, sentence1Words) * weight for word, weight in zip(sentence2Words, weightVector2)]
        return (sum(vector1) + sum(vector2)) / (sum(weightVector1) + sum(weightVector2))

def create_connection():
    return MySQLdb.connect(
        host="192.168.73.27",
        user="root",
        passwd="r#dcenter9",
        db="iBot",
        charset='utf8')

matcher_dict_1 = {
    0: u"创业板的企业如果连续亏损会被加st吗？",
    1: u"哪些股票是创业板股票？",
    2: u"创业板权限开通生效时间",
    3: u"创业板转签生效时间",
    4: u"可以在异地营业部申请开通创业板权限吗？",
    5: u"创业板权限如何取消？",
    6: u"创业板权限首次开通？",
    7: u"信用账户与普通账户的创业板权限需单独开立吗？",
    8: u"创业板权限开通的办理时间",
    9: u"创业板转签申请时间",
    10: u"创业板权限开通或转签是否要收费？",
}

matcher_dict_2 = {
    0: u"当日买入的港股当日是否可以卖出",
    1: u"港股红利资金派发到账时间",
    2: u"港股开市价产生规则",
    3: u"港股通额度如何安排",
    4: u"港股通分红方式",
    5: u"港股通股票持仓查询方法",
    6: u"港股通股票浮动盈亏，成本价计算方法",
    7: u"港股通股票股息红利扣税规则",
    8: u"港股通交收规则",
    9: u"港股通交易方式",
    10: u"港股通交易废单常见原因",
    11: u"港股通交易费用",
    12: u"港股通交易后何时可以查询资金流水",
    13: u"港股通交易货币",
    14: u"港股通交易能否进行融资融券",
    15: u"港股通交易权限如何取消",
    16: u"港股通交易日查询方法",
    17: u"港股通交易软件下载方法",
    19: u"港股通交易时间",
    20: u"港股通交易佣金收费规则",
    21: u"港股通开通方法",
    22: u"个人投资者港股通开通条件",
    23: u"港股通交易权限生效时间",
    24: u"港股通交易权限能否网上开通",
    25: u"港股通能否在多个券商开通",
    26: u"港股通交易佣金收费规则",
    27: u"港股通委托指令限制",
    28: u"港股通整手股数及申报机制",
    29: u"港股通最小报价单位",
    30: u"海通支持港股通五档行情的软件",
    31: u"沪港通标的证券和深港通标的证券区别",
    32: u"沪港通和深港通的区别",
    33: u"深港通股票能否办理转托管",
}

def model_loader():
    #model_path = "D:\Coding\python\shorttext_agg\word2vec\w2v.model\w2v\w2v.model_21_f"
    model_path = r"qatest/model/w2v.model_21_f"
    w2v = Word2Vec(model_path, kind='bin')
    return w2v

def all_candidate_loader():
    return list(matcher_dict_1.values()) + list(matcher_dict_2.values())

def all_candidate_pos_dict(domain):
    conn = create_connection()

    result1 = []
    result2 = []

    try:
        result1 = get_knowledge_dict(conn, domain)
        result2 = get_question_dict(conn, domain)
    finally:
        conn.close()

    matcher_dict = []

    if result1:
        for item in result1:
            matcher_dict.append((item[0], list(jieba.cut(item[0]))))

    if result2:
        for item in result2:
            matcher_dict.append((item[0], list(jieba.cut(item[0]))))

    #all_candidate_list = all_candidate_loader()
    #return dict([(candidate, list(jieba.cut(candidate))) for candidate in all_candidate_list])
    return dict(matcher_dict)

w2v_global_model = model_loader()



def rule_pattern(input_sentence):
    r_list_3 = call_func_3(input_sentence, category_priority_nest_list_f_3)
    conclusion = eval_call_conclusion_3(r_list_3, category_priority_nest_list_f_3)
    if conclusion is not None:
        return conclusion

    r_list_4 = call_func_4(input_sentence, category_priority_nest_list_f_4)
    conclusion = eval_call_conclusion_4(r_list_4, category_priority_nest_list_f_4)
    return conclusion

# Create your views here.

def get_knowledge_dict(conn, domain):
    cursor = conn.cursor()

    try:
        sql = '''SELECT `title`
                FROM `Knowledge`
                WHERE `domain` = \'%s\'''' % domain
        cursor.execute(sql)
        return cursor.fetchall()
    except Exception as e:
        return None
    finally:
        cursor.close()

def get_question_dict(conn, domain):
    cursor = conn.cursor()

    try:
        sql = '''SELECT `question` as `title`
                FROM `Question`
                WHERE `domain` = \'%s\'''' % domain
        cursor.execute(sql)
        return cursor.fetchall()
    except Exception as e:
        return None
    finally:
        cursor.close()

def get_knowledge(conn, domain, questions):
    cursor = conn.cursor()

    try:
        sql = '''SELECT `knowledgeId`,
                        `title`
                FROM `Knowledge`
                WHERE `domain` = \'%s\'
                AND `title` IN (\'%s\')''' % (domain, '\',\''.join(questions))
        cursor.execute(sql)
        return cursor.fetchall()
    except Exception as e:
        return None
    finally:
        cursor.close()

def get_question(conn, domain, questions):
    cursor = conn.cursor()

    try:
        sql = '''SELECT `Question`.`question_type_id`,
                        `Question`.`question`,
                        `Knowledge`.`title`
                FROM `Question`
                LEFT JOIN `Knowledge` ON `Question`.`question_type_id` = `Knowledge`.`knowledgeId`
                WHERE `Question`.`domain` = \'%s\'
                AND `Question`.`question` IN (\'%s\')''' % (domain, '\',\''.join(questions))
        cursor.execute(sql)
        return cursor.fetchall()
    except Exception as e:
        return None
    finally:
        cursor.close()

def retrieve_answer(sentence, domain):
    sentence_pos = list(jieba.cut(sentence))

    all_candidate_dict = all_candidate_pos_dict(domain)

    val_dict = defaultdict(float)

    for candidate, candidate_pos in all_candidate_dict.items():
        smi_val = w2v_global_model.sentence_similarity(sentence_pos, candidate_pos)
        val_dict[candidate] = smi_val

    order_tuple_2 = sorted(val_dict.items(), key=lambda t2: -1 * t2[-1])

    order_tuple_2 = order_tuple_2[:6]

    msgs = [item[0] for item in order_tuple_2]

    #max_candidate = order_tuple_2[0][0]
    #max_candidate_val = order_tuple_2[0][1]

    # 规则 正则表达式
    #if max_candidate_val < w2v_sim_threshold:
    #    max_candidate = rule_pattern(sentence)
    #    max_candidate_val = None

    # 相似度结果 前6个 去数据库查询 标准问 扩展问 精确匹配
    #max_price = 5
    #response_data = dict()
    #response_data["max_simlarity_val"] = max_candidate_val
    #response_data["max_simlarity_sent"] = max_candidate

    result1 = []
    result2 = []

    if msgs:
        conn = create_connection()

        try:
            result1 = get_knowledge(conn, domain, msgs)
            result2 = get_question(conn, domain, msgs)
        finally:
            conn.close()

    # 要么在标准要么在扩展

    result = {}

    # 统一成标准问的问题

    knowledge_ids = []
    if result1:
        for item in result1:
            knowledge_ids.append(item[0])
            result[item[1]] = (item[0], 'knowledge', item[1])

    if result2:
        for item in result2:
            result[item[1]] = (item[0], 'knowledgeAsk', item[2])

    records = []
    for item in order_tuple_2:
        data = result.get(item[0])

        if data and not (data[1] == 'knowledgeAsk' and data[0] in knowledge_ids):
            records.append({
                "knowledgeId": data[0],
                "title": data[2],
                "score": item[1],
                "type": data[1]
            })

    records = sorted(records, key=lambda x: -x['score'])

    question_ids = []
    new_records = []
    for item in records:
        if item['knowledgeId'] not in question_ids:
            question_ids.append(item['knowledgeId'])
            new_records.append({
                "knowledgeId": item['knowledgeId'],
                "title": item['title'],
                "score": item['score'],
                "type": item['type']
            })

    return new_records
