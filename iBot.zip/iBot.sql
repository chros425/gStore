/*
Navicat MySQL Data Transfer

Source Server         : log1
Source Server Version : 50505
Source Host           : 192.168.73.27:3306
Source Database       : iBot

Target Server Type    : MYSQL
Target Server Version : 50505
File Encoding         : 65001

Date: 2018-05-29 18:57:26
*/

SET FOREIGN_KEY_CHECKS=0;

-- ----------------------------
-- Table structure for Knowledge
-- ----------------------------
DROP TABLE IF EXISTS `Knowledge`;
CREATE TABLE `Knowledge` (
  `domain` varchar(255) DEFAULT NULL,
  `knowledgeId` varchar(255) DEFAULT NULL,
  `title` varchar(255) DEFAULT NULL,
  `catalogId` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of Knowledge
-- ----------------------------
INSERT INTO `Knowledge` VALUES ('domain', '1', '创业板开通条件', null);
INSERT INTO `Knowledge` VALUES ('domain', '2', '333', null);
INSERT INTO `Knowledge` VALUES ('domain', '3', null, null);
INSERT INTO `Knowledge` VALUES ('domain', '4', 'knowledge 1 edit', 'catalogId_1');
INSERT INTO `Knowledge` VALUES ('domain', '5', 'knowledge 2 edit', 'catalogId_2_edit');
INSERT INTO `Knowledge` VALUES ('domain', '6', null, null);
INSERT INTO `Knowledge` VALUES ('domain', '7', 'knowledge_200', 'catalogId_200');
INSERT INTO `Knowledge` VALUES ('gfzq', '8', 'knowledge_1', 'catalogId_1');
INSERT INTO `Knowledge` VALUES ('gfzq', '9', 'knowledge999edit', 'catalogId_999');
INSERT INTO `Knowledge` VALUES ('gfzq', '2', 'knowledge 2', 'catalogId_2');

-- ----------------------------
-- Table structure for Question
-- ----------------------------
DROP TABLE IF EXISTS `Question`;
CREATE TABLE `Question` (
  `question_id` varchar(255) NOT NULL,
  `question_type` varchar(255) DEFAULT NULL,
  `question_type_id` int(11) DEFAULT NULL,
  `question` varchar(255) DEFAULT NULL,
  `domain` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`question_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

-- ----------------------------
-- Records of Question
-- ----------------------------
INSERT INTO `Question` VALUES ('1', '1', '1', '创业板必须到营业厅开通吗', 'domain');
INSERT INTO `Question` VALUES ('70a5f868-631e-11e8-aa62-1002b5d30e6d', '1', '21', 'ask edit of knowledge 3333', 'gfzq');
INSERT INTO `Question` VALUES ('8f3b8840-6329-11e8-96c3-000c29f63908', '1', '2', 'ask1 of knowledge 2', 'gfzq');
INSERT INTO `Question` VALUES ('8f3bce90-6329-11e8-96c3-000c29f63908', '1', '2', 'ask2 of knowledge 2', 'gfzq');
